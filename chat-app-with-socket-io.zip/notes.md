# Notes

### TODO

[-] Add badwords filter like [this](https://replit.com/@RolandJLevy/js-all-in-one-search-with-autocomplete#script.js)
[-] [Broadcasting an Image to Other Sockets](https://www.youtube.com/watch?v=RCXDlpCorhk)
[-] File upload with [multer](https://bezkoder.com/node-js-express-file-upload/)
[+] display emoji dropdown on desktop view onky
[+] on focus event for input elements, add a class which reduces up the chat window height. On blur revert back to full height
[+] Add the required attr to input fields or disable Send button
[+] Test keyup / touchend events on mobiles
[+] Improve UX for mobiles - when mobile keyboard opens

### socket-io examples

- https://replit.com/@amasad/socket-io-example
- https://replit.com/@abdulrahmand/Socket-IO-Chat-Example
- https://replit.com/@zakaton/socketio-client

### Youtube tutorial

- [Tutorial on Github](https://github.com/iamshaunjp/websockets-playlist)
- [Tutorial 1](https://www.youtube.com/watch?v=vQjiN8Qgs3c)
- [Tutorial 2](https://www.youtube.com/watch?v=ggVsXljT0MI)
- [Tutorial 3](https://www.youtube.com/watch?v=UwS3wJoi7fY)
- [Tutorial 4](https://www.youtube.com/watch?v=KNqVpESuyQo)
- [Tutorial 5](https://www.youtube.com/watch?v=FvArk8-qgCk)

### Reference

- [Socket.io](https://socket.io)
- [Getting started](https://socket.io/get-started/private-messaging-part-1/)
- [CDN for frontend](https://cdn.socket.io/4.0.1)
- [XSS Filter Evasion Cheat Sheet](https://owasp.org/www-community/xss-filter-evasion-cheatsheet)

### Emoji dropdown

- [create emoji dropdown](https://stackoverflow.com/questions/39871916/is-it-possible-to-generate-all-the-emojis-and-append-to-the-select-dropdown)
- [emoji library](https://github.com/theraot/emoji)